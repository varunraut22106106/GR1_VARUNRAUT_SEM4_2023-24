<?php include("includes/header.php") ?>
<?php include("includes/nav.php") ?>
<div class="jumbotron">
    <?php activate_user(); ?>
    <?php activate_admin(); ?>
    <h1 class="text-center">Activate</h1>
</div>
<?php include("includes/footer.php") ?>



