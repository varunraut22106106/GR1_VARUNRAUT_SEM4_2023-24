<?php ob_start();
session_start();
include("admin_db.php");
include("admin_function.php");
?>