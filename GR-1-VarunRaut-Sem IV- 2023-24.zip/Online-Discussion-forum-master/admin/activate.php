<?php include "includes/admin_header.php";?>
<?php include "includes/admin_navigation.php" ?>
   <?php activate_admin(); ?>
<div class="jumbotron">

 
    <h1 class="text-center">Activate</h1>
</div>
<?php include "includes/admin_footer.php" ?>



