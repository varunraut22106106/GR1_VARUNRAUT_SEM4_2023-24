<?php include("functions/admin_init.php"); ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>ODF Admin</title>
        <!-- Bootstrap Core CSS -->
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/sb-admin.css" rel="stylesheet">
        <link href="css/comment.css" rel="stylesheet">
        <!-- Custom Fonts -->
        <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <link href="css/styles.css" rel="stylesheet">
        
        <script type="text/javascript" src="https://www.google.com/jsapi"></script>
        
        <script src="http://tinymce.cachefly.net/4.1/tinymce.min.js"></script>
        
        <script src="js/jquery.js"></script>
        
        <!-- Favicon -->
        <link rel="shortcut icon" type="image/png" href="img/admin-with-cogwheels.png">

    </head>
    <body>